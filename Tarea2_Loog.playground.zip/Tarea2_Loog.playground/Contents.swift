//: Playground - noun: a place where people can play

import UIKit

enum Velocidades : Int {
    case Apagado = 0, VelocidadBaja = 20, VelocidadMedia = 50, VelocidadAlta = 120
    
    init( velocidadInicial : Velocidades ){
        self = velocidadInicial
    }
}

class Auto{
    var velocidad : Velocidades
    
    init(){
        velocidad = Velocidades.init(velocidadInicial: .Apagado)
    }
    
    func cambioDeVelocidad() -> (actual : Int, velocidadEnCadena : String){
        
        switch velocidad {
        case .Apagado:
            velocidad = .VelocidadBaja
            let resultado = (0, "Apagado")
            return resultado
        case .VelocidadBaja:
            velocidad = .VelocidadMedia
            let resultado = (20, "Velocidad Baja")
            return resultado
        case .VelocidadMedia:
            velocidad = .VelocidadAlta
            let resultado = (50, "Velocidad Media")
            return resultado
        case .VelocidadAlta:
            velocidad = .VelocidadMedia
            let resultado = (120, "Velocidad Alta")
            return resultado
        }
    }
}

var auto : Auto

for i in 1...20{
    var actualizar = auto.cambioDeVelocidad()
    print (actualizar.actual, actualizar.velocidadEnCadena)
}










