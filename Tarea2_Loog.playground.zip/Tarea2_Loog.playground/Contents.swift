//: Playground - noun: a place where people can play

import UIKit

enum Velocidades : Int {
    case Apagado = 0, VelocidadBaja = 20, VelocidadMedia = 50, VelocidadAlta = 120
    
    init( velocidadInicial : Velocidades ){
        self = .Apagado
    }
}

class Auto {
    var velocidad : Velocidades
    
    init(velocidad: Velocidades){
        self.velocidad = .Apagado
    }
    
    func cambioDeVelocidad(velocidad:Velocidades) -> (actual : Int, velocidadEnCadena : String){
        
        switch velocidad {
        case .Apagado:
            let resultado = (20, "Velocidad Baja")
            return resultado
        case .VelocidadBaja:
            let resultado = (50, "Velocidad Media")
            return resultado
        case .VelocidadMedia:
            let resultado = (120, "Velocidad Alta")
            return resultado
        case .VelocidadAlta:
            let resultado = (50, "Velocidad Media")
            return resultado
        }
    }
}

var auto : Auto

for i in 1...20{
    print (cambioDeVelocidad(actual: , velocidadEnCadena:))
}










